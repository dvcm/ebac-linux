

def addition_operation(num_1, num_2):
    addition = num_1 + num_2
    return addition


def subtraction_operation(num_1, num_2):
    subtraction = num_1 - num_2
    return subtraction
